<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8">
		<title> Accueil</title>
		<link rel="stylesheet" type="text/css" media="screen" href="https://cdn.staticfile.org/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="css/accueil.css">	
<script type="text/javascript">	
function confirmation(){
	
	 if(confirm("Voulez-vous deconnecter?"))
  {
    
    window.location.href="sortie.php";
    return true;
  }
  else
  {
    return false;
  }

}

</script>

	</head>
    <body>
    <?php 
    include('connexion.php');
    session_start();
    if(isset($_SESSION['id']))
    	$id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
    ?>
	<div class="head" id="head">
  <div class="title">Systeme de News</div>
  
  <?php
	if(isset($_SESSION['id'])){
		echo "<em style='float:right; color:white;'>Bienvenue"." ".$_SESSION['prenom']." ".$_SESSION['nom']." "."</em>";
		//echo "Bienvenue".$_SESSION['prenom'].$_SESSION['nom'];
	}
	else {
		echo "<em style='float:right;color:white;'>Bienvenue,Guest"."  "."</em>";
	}
	?>
  </div>
	<div class="centre" id="centre">
	<ul>
  	<li><a href="#home" class="active1"><i class="icon ion-home"></i>  Acceuil</a></li>
  	<div class="nav">
    <a href="#" class="navbtn">News</a>
    <div class="sousmenu-content">
      <a href="rediger.php"> Écrire un article </a>
      <a href="articleListe.php">Liste d'article </a>
    </div>
  </div>
  	<li><a href="#gestion">Gestion</a></li>
  	
  	<?php 
  	if(isset($_SESSION['id'])){
  	 echo "<li style='float:right'><a class='active' href='modifier.php'>Modifier</a></li>
  	 <li style='float:right'><a class='active' onclick='return confirmation()'>Se deconnecter</a></li>";
  	}
  	else {

  	echo "<li style='float:right'><a class='active' href='inscriptionform.php'>S'inscrire</a></li>
  	<li style='float:right'><a class='active' href='login.php'>Se connecter</a></li>";
  	}
  	?>
	</ul>
		
    <div class="recherche">

    <form method="post" action="accueil.php" calss="rechecheform">
	<select name="recherche">
	<?php
		if (isset($_POST['recherche']))
			$recherche = $_SESSION['recherche'] =$_POST['recherche'];
		else if (isset($_SESSION['recherche']))
			$recherche = $_SESSION['recherche'];
		else $recherche = 0;
		echo "<option value='0' ".($recherche == 0 ? 'selected':'').">Par date</option>
		<option value='1' ".($recherche == 1 ? 'selected':'').">Par thème</option>";
	?>
	</select>
	<input type="submit" class="search" value="Recherche">
    </form>
	</div>
	
	<div class="panel">
		<div class="panelinput">

	<?php
		
		$pageSize = 2; 
		$result = $objPdo->query("select * from NEWS");
		$totalNum = $result->rowCount(); 
		$totalPageCount = ceil($totalNum/$pageSize); 
		$nowPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
		$prev = ($nowPage-1 <= 0) ? 1 : $nowPage-1;
		$next = ($nowPage+1 >= $totalPageCount) ? $totalPageCount : $nowPage+1;
		$offset = ($nowPage-1)*$pageSize;
		//$sql = "SELECT `idnews`,`idtheme`,`titrenews`,`datenews`,`textenews`,`idredacteur` FROM `NEWS` LIMIT :offset, :pageSize";
		$stmt = $objPdo ->prepare("SELECT `idnews`,`idtheme`,`titrenews`,`datenews`,`textenews`,`idredacteur` FROM `NEWS` LIMIT :offset, :pageSize");
		$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
		$stmt->bindParam(':pageSize', $pageSize, PDO::PARAM_INT);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$res = $stmt->fetchAll();
	?><?php		
	if($recherche == 1)
	{		
		
		
		$sql = "SELECT * FROM NEWS NEWS, THEME, REDACTEUR
			where NEWS.idtheme=THEME.idtheme
			and REDACTEUR.idredacteur=NEWS.idredacteur order by NEWS.idtheme LIMIT :offset, :pageSize";
		$stmt = $objPdo->prepare($sql);
		$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
		$stmt->bindParam(':pageSize', $pageSize, PDO::PARAM_INT);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$res = $stmt->fetchAll();
		
		
		foreach ($res as $row){
			echo "<h1 style='text-align: center;color: white;background-color: #acd6ff;padding:-10px;'>". $row ['titrenews'] ."</h1>";
			echo "<p style='background-color:#84c1ff;overflow: auto;height:100px;max-width: 98%;resize: both; padding-buttom:50px;'>". $row['textenews']."</p>"."<br>";
			echo "<p style='float:left'>Thème : ". $row['description']."<p style='float:right' >Écrit par ". $row['prenom'] . " ". $row['nom'] . ", le ". $row["datenews"]."</p></p>"."<br>";
		}
		$result->closeCursor() ;
	}

	else if($recherche == 0){
		
		
		$sql = "select *,DATE_FORMAT(datenews,'%d-%m-%Y à %H:%i') as date
			from NEWS,THEME,REDACTEUR 
			where NEWS.idtheme=THEME.idtheme
			and REDACTEUR.idredacteur=NEWS.idredacteur order by date desc LIMIT :offset, :pageSize";
		$stmt = $objPdo->prepare($sql);
		$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
		$stmt->bindParam(':pageSize', $pageSize, PDO::PARAM_INT);
		$stmt->execute();
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		$res = $stmt->fetchAll();
		
		
		foreach ($res as $row){
			echo "<h1 style='border-bottom: 3px solid RGB(129, 207, 224);'>". $row ['titrenews'] ."</h1>" ;
			echo "<p style='background-color: #acd6ff;overflow: auto;height: 100px;max-width: 98%;resize : both; margin-buttom:50px;'>". $row['textenews']. "</p>"."<br>";
			echo "<p style='float:left'>Thème : ". $row['description']."<p style='float:right'>Écrit par ". $row['prenom'] . " ". $row['nom'] . ", le ". $row["datenews"]."</p></p>"."<br>";
		
		}
		$result->closeCursor() ;
		}
		?>	
		</div>
			<?php
			echo '<h3 align="center">';
				
				for ($i=1; $i<=$totalPageCount; $i++) {
					
    			echo "<a class='page' style='font-size: 12px;background-color: RGB(55, 82, 151);color: white; padding: 6px 10px;text-decoration: none;margin-left:10px ;margin-top:10px;' href=\"".$_SERVER['PHP_SELF']."?page=".$i.'">'.$i.'</a>';
				
    			}
				echo '</h3>';
		?>
	</div>
</div>
	<div class="footer" id="foot">
	<div class="picture"><img src="images/ciel2.png"/></div>
  <div class="copyright">
    <p>Copyright © 2018 </p>
	<div class="img">
		<i class="icon1"></i><span>Université de Lorraine</span>
	</div>
	  
  </div>
	
</div>
	
	
</body>
</html>
	</body>
</html>
	</body>
</html>