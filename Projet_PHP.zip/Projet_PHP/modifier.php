<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8">
		<title>Form_Modifier_Motdepasse</title>
		<link rel="stylesheet" type="text/css" media="screen" href="https://cdn.staticfile.org/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="css/modifier.css">
	<script type="text/javascript">
	function modifier(){
	var oldmotdepasse = document.getElementById("oldmotdepasse").value;
	var newmotdepasse = document.getElementById("newmotdepasse").value;
	var confirmation = document.getElementById("confirmation").value;
	
	if(oldmotdepasse.length==0||oldmotdepasse.trim()==""
){
	alert("le champ de mot de passe est vide");
	return false;
	}
	if(newmotdepasse.length==0||newmotdepasse.trim()==""){
	alert("le champ de nouveau mot de passe est vide");
	return false;
	}
	if(newmotdepasse==oldmotdepasse){
		alert("le mot de passe et le nouveau mot de passe sont le même");
		return false;
		}
	if(confirmation.length==0||confirmation.trim()=="")
	{
	alert("le champ de confirmation est vide");
	return false;
	}
	if(newmotdepasse!=confirmation){
		alert("le mot de passe et la confirmation de  mot de passe ne sont pas le même");
		return false;
		}
	return true;
	}
</script>
	</head>
	<body>
	
	
	<?php
    include('connexion.php');
    session_start();
    if(isset($_SESSION['id']))
    	$id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
    ?>
    <?php
	if(isset($_SESSION['id'])){
		$req = $objPdo->prepare("select * from REDACTEUR where idredacteur =$id");
		$req->execute();
			if($objligne=$req->fetch(PDO::FETCH_OBJ))
			{
			$adressmail=$objligne->adressemail;
			$motdepasse=$objligne->motdepasse;
			}
	
	}
	else{
		?>
		
		<script type ="text/javascript">
			alert("le redacteur existe pas!");
			window.location.href="accueil.php";
		</script>
		<?php
		}
		
	?>
	
	
	<div class="header" id="head">
  <div class="title">System de News</div>
  </div>
  <form action="modifier_motdepasse.php" method="post" onsubmit="return modifier()"> 
 <div class="wrap" id="wrap">
		<div class="logGet">
			<div class="logD logDtip">
				<p class="p1">Modifier</p>
			</div>
			
  		<div class="lgD">
  			<i class="icon ion-ios-locked-outline"></i> 
   			<input type="password" class="textfield" placeholder="mot de passe" name="oldmotdepasse" id="oldmotdepasse"/>
   		</div>
   		<div class="lgD">
  			<i class="icon ion-ios-locked-outline"></i>
   			<input type="password" class="textfield" placeholder="nouveau mot de passe" name ="newmotdepasse" id="newmotdepasse"/>
   		</div>
   		<div class="lgD">
  			<i class="icon ion-ios-locked-outline"></i>
  			<input type="password" class="textfield" placeholder="confirmation" name="confirmation" id="confirmation"/>
  		</div>
  		<div class="logC">
  			 <input type="submit" value="modifier"  class="button" onclick = "return modifer()">
   		</div>
  		 <div class="logE">
			<a class="reme2" href="accueil.php">Annuler</a> 
		</div> 
   		</div>
    </form>	
    
<div class="footer" id="foot">
  <div class="copyright">
    <p>Copyright © 2018 </p>
	<div class="img">
		<i class="icon1"></i><span>Université de Lorraine</span>
	</div>
	  
  </div>
	
</div>
	
	
</body>
</html>